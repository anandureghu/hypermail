const appConfig = require("./app.config");
const mailConfig = require("./mail.config");

module.exports = {
  app: appConfig,
  mail: mailConfig,
};
