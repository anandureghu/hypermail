const imageRouter = require("../app/image/image.routes");
const mailRouter = require('../app/mail/mail.routes');

module.exports = {
  imageRouter,
  mailRouter
};
