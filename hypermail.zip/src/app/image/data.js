const datas = [
  { name: "John Doe", email: "john.doe@qburst.com" },
  { name: "Peter Parker", email: "peter.parker@qburst.com" },
];

module.exports = {
  datas,
};
